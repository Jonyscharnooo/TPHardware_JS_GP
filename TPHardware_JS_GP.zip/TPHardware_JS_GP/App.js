import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './screens/Home';
import Contacto from './screens/Contacto';
import Emergencia from './screens/Emergencia';
import QR from './screens/QR';
import Clima from './screens/Clima';

export default function App() {
  const Stack = createNativeStackNavigator();
  return (
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen
            name="Home"
            component={Home}
            options={{title:'Home'}}
          />
          <Stack.Screen
            name="Emergencia"
            component={Emergencia}
            options={{title:'Emergencia'}}
          />
          <Stack.Screen
            name="Contacto"
            component={Contacto}
            options={{title:'Contacto'}}
          />
          <Stack.Screen
            name="QR"
            component={QR}
            options={{title:'QR'}}
          />
          <Stack.Screen
            name="Clima"
            component={Clima}
              options={{title:'Clima'}}
          />
        </Stack.Navigator>
      </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
