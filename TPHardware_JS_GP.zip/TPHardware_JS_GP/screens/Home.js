import React from 'react';
import { StyleSheet, View, SafeAreaView, Text, TouchableOpacity } from 'react-native';

const Home = ({ navigation }) => (
  <SafeAreaView style={styles.container}>
    <View style={styles.header}>
      <Text style={styles.title}>TP Hardware</Text>
      <Text style={styles.subtitle}>Jonathan Scharnopolsky & Gonzalo Plager</Text>
      <Text style={styles.subtitle}>ORT 2023</Text>
    </View>
    <View style={styles.buttonContainer}>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Emergencia')}
      >
        <Text style={styles.buttonText}>Número de Emergencia</Text>
      </TouchableOpacity>
    </View>
    <View style={styles.buttonContainer}>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Contacto')}
      >
        <Text style={styles.buttonText}>Contactos</Text>
      </TouchableOpacity>
    </View>
    <View style={styles.buttonContainer}>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('QR')}
      >
        <Text style={styles.buttonText}>Acerca del proyecto / Escaner QR</Text>
      </TouchableOpacity>
    </View>
    <View style={styles.buttonContainer}>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Clima')}
      >
        <Text style={styles.buttonText}>Clima</Text>
      </TouchableOpacity>
    </View>
  </SafeAreaView>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#FFD0C5',
    paddingHorizontal: 16,
  },
  header: {
    alignItems: 'center',
    marginVertical: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF8E73',
  },
  subtitle: {
    fontSize: 16,
    color: '#FF8E73',
  },
  buttonContainer: {
    marginVertical: 10,
  },
  button: {
    backgroundColor: '#FF8E73',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    marginHorizontal: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

export default Home;