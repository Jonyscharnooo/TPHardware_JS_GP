import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Button, Image, Vibration, Text } from 'react-native';
import { BarCodeScanner } from 'expo-barcode-scanner';

const QR = ({ navigation }) => {
  const [mostrarQR, setMostrarQR] = useState(true);
  const alertar = (alertar) => {
    alert(alertar.data);
    setMostrarQR(true);
  };

  return (
    <View style={styles.container}>
      {mostrarQR ? (
        <View style={styles.qrContainer}>
          <Image style={styles.image} source={require('../assets/QR_JS_GP.png')} />
          <Button title="Escanear código QR" onPress={() => setMostrarQR(false)} />
        </View>
      ) : (
        <BarCodeScanner
          onBarCodeScanned={alertar}
          style={StyleSheet.absoluteFillObject}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0', // Cambia el color de fondo a gris claro
  },
  qrContainer: {
    alignItems: 'center',
  },
  image: {
    width: 200, // Reducí el tamaño de la imagen
    height: 200, // Reducí el tamaño de la imagen
    marginBottom: 20, // Agregué un margen inferior para separarla del botón
  },
  boton: {
    marginTop: 20, // Ajusté el margen superior del botón
  },
});

export default QR;