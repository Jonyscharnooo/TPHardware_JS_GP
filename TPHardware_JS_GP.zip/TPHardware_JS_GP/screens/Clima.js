import { StyleSheet, Text, View, Vibration } from "react-native";
import { useState, useEffect } from 'react';
import * as Location from 'expo-location';
import axios from "axios";

const Clima = () => {
  const [clima, setClima] = useState(null);

  useEffect(() => {
    (async () => {
      let permiso = await Location.requestForegroundPermissionsAsync();
      if (permiso.status !== 'granted') {
        console.error("Permiso denegado");
        Vibration.vibrate();
        alert("Permiso denegado");
        return;
      }

      try {
        const location = await Location.getCurrentPositionAsync();
        const apiKey = 'f20492a9c67baeac96fa4b2b4f3d8620';

        const response = await axios.get(
          `https://api.openweathermap.org/data/2.5/weather?lat=${location.coords.latitude}&lon=${location.coords.longitude}&appid=${apiKey}&units=metric`
        );

        setClima(response.data);
      } catch (error) {
        console.error(error);
        Vibration.vibrate();
      }
    })();
  }, []);

  return (
    <View style={styles.container}>
        <View style={styles.header}>
        <Text style={styles.title}>Clima</Text>
        <Text style={styles.subtitle}>Temperatura, fecha, hora y ubicación actuales</Text>
    </View>
      {clima && (
        <View style={styles.weatherInfo}>
          <Text style={styles.weatherText}>Temperatura actual: {clima.main.temp}°C</Text>
          <Text style={styles.weatherText}>Fecha y hora: {new Date(clima.dt * 1000).toLocaleString()}</Text>
          <Text style={styles.weatherText}>Ubicación: {clima.name}, {clima.sys.country}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: "#FFD0C5",
  },
  header: {
    alignItems: 'center',
    marginVertical: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF8E73',
  },
  subtitle: {
    fontSize: 16,
    color: '#FF8E73',
  },
  weatherInfo: {
    backgroundColor: "#FF8E73",
    padding: 16,
    borderRadius: 10,
  },
  weatherText: {
    fontSize: 16,
    marginBottom: 8,
    color: "#FFFFFF",
  },
});

export default Clima;