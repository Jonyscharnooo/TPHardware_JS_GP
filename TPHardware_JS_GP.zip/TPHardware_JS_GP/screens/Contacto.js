import React, { useState, useEffect } from "react";
import { FlatList, SafeAreaView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import * as Contacts from 'expo-contacts';

const ContactItem = ({ contact, onPress }) => (
  <TouchableOpacity onPress={onPress} style={styles.item}>
    <Text style={styles.contactName}>{contact.name}</Text>
    {contact.phoneNumbers && contact.phoneNumbers.length > 0 && (
      <Text style={styles.phoneNumber}>{contact.phoneNumbers[0].number}</Text>
    )}
  </TouchableOpacity>
);

const Contacto = () => {
  const [contactos, setContactos] = useState([]);

  useEffect(() => {
    (async () => {
      const { status } = await Contacts.requestPermissionsAsync();
      if (status === 'granted') {
        const { data } = await Contacts.getContactsAsync({
          fields: [Contacts.Fields.PhoneNumbers, Contacts.Fields.FirstName, Contacts.Fields.LastName],
        });

        if (data.length > 0) {
          setContactos(data);
        }
      }
    })();
  }, []);

  const renderItem = ({ item }) => (
    <ContactItem contact={item} onPress={() => handleContactPress(item)} />
  );

  const handleContactPress = (contact) => {
  };

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={contactos}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  contactName: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  phoneNumber: {
    fontSize: 16,
    color: 'gray',
  },
});

export default Contacto;